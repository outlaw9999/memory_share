# Project Intelligence (AGENTS.md)

**STATUS:** Minimal Cognitive Protocol (v1.2.3)

## Cognitive Compass

This file is a POINTER, not a database.
All knowledge, decisions, and history are stored in .kit.

> Always rely on .kit, NOT this file.

## Agent Operating Protocol

### 1. Memory Authority (MANDATORY)

- Before any task: `kit recall`
- Treat .kit as single source of truth
- Do NOT infer from old code or comments without recall

### 2. Learning Rituals

| Situation | Command |
|-----------|---------|
| Bug / Friction | `kit learn --auto` |
| Decision / Pattern | `kit learn --content "..." --kind decision` |

### 3. Atomic Learn Protocol (CRITICAL)

- 1 idea per entry
- ≤ 20 words
- No explanation
- No special chars (>, |, &)
- Use simple natural language

```
✅ Correct:
"province ưu tiên hơn ward khi không có prefix"

❌ Wrong:
"province > ward because..."
```

### 4. Session Hygiene

- Break tasks into small steps
- Avoid long context accumulation
- Max autonomous attempts: 5 (then surface blocker)

## Navigation

```bash
kit recall <keyword>
kit symbol <query>
kit context <symbol>
```

## Architecture (High-Level Only)

Deterministic pipeline:
```
API → Normalize → Validate → Model → Export
```

Core principles:
- Normalize first, validate after
- No None after normalization
- Data integrity over convenience

## Anti-Patterns

- Do NOT store knowledge in this file
- Do NOT duplicate .kit memory here
- Do NOT write long explanations
- Do NOT skip `kit recall`

## System Philosophy

- `.kit` = Memory (Authority)
- `AGENTS.md` = Compass (Navigation)

## TL;DR

```
kit recall → before doing anything
Do task
Hit bug → kit learn --auto
Have insight → kit learn --content ... --kind decision
```

> If unsure → recall first, act later.

---

*Last Updated: 2026-03-23* | *v1.2.3*
