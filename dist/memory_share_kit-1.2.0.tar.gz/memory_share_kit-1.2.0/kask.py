import sys
import os
import subprocess
from kit_agent.utils.process import safe_run
from kit_agent.providers.local import LocalLLMProvider

def kask(query: str):
    print(f"[*] Recalling context from .kit...")
    # 1. Recall context using kit.py
    stdout, stderr, code = safe_run(["python", "kit.py", "recall", query, "--fast"])
    if code != 0:
        print(f"[!] Error recalling context: {stderr}")
        context = ""
    else:
        context = stdout

    # 2. Query Jan v3 (Local LLM)
    print(f"[*] Querying Jan v3 (Local LLM)...")
    provider = LocalLLMProvider()
    
    # We inject the context into the prompt
    prompt = f"PROJECT CONTEXT:\n{context}\n\nUSER QUESTION: {query}"
    
    result = provider.ask(prompt)
    
    if result["ok"]:
        print("\n=== RESPONSE ===")
        print(result["text"])
        print("\n================")
        
        # 3. Optional: Auto-learn (Episodic memory)
        # safe_run(["python", "kit.py", "learn", "--tag", "note", f"Q: {query}\nA: {result['text']}"])
    else:
        print(f"[!] Local LLM Error: {result['error']}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python kask.py \"your question\"")
        sys.exit(1)
        
    kask(" ".join(sys.argv[1:]))
