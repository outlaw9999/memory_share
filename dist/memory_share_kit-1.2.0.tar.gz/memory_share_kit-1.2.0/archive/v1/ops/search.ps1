﻿# Search Brain
param(
    [string]$Query,
    [switch]$IncludeStream,
    [switch]$IncludePrivate
)

$root = Resolve-Path "$PSScriptRoot\.."

Get-ChildItem "$root\layer2_core" *.md -ErrorAction SilentlyContinue | Select-String "$Query"

if ($IncludeStream) {
    Get-ChildItem "$root\layer1_stream" *.md -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime |
        Select-Object -Last 5 |
        Select-String "$Query"
}

if ($IncludePrivate -and (Test-Path "$root\layer2_private")) {
    Get-ChildItem "$root\layer2_private" *.md -ErrorAction SilentlyContinue | Select-String "$Query"
}
