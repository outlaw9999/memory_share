# AGENT COGNITIVE BOOTLOADER

> **STATUS:** Kit v1.2.3 STABLE
> **WARNING:** This file is the operating constitution, not the project memory database.

## 1. Mandatory Startup Sequence

Before taking action in this repository:

```bash
kit recall
```

Use `kit recall` first. Open docs only when you need more detail.

## 2. Minimal Navigation

1. `AGENTS.md` for startup laws
2. `docs/reference.md` for exact commands
3. `scripts/kitf.ps1` for friction logging on Windows

## 3. Iron Laws Of Memory

1. Never treat markdown as long-term memory. `.kit` is the authority.
2. Never guess paths or structure. Inspect the repo first.
3. Never store project business logic in this file.
4. Log friction with `kit learn --auto` or `scripts/kitf.ps1`.
5. Store decisions with short atomic entries.

## 4. Fast Start

```text
kit recall -> hydrate local starter memory
Inspect repo -> avoid blind edits
Open reference.md only for exact syntax
kit learn --auto -> capture friction
```

> If unsure, recall first and act later.

---

*Last Updated: 2026-03-29* | *v1.2.3*
